import { useState } from "react";
import { login, register } from "../api/fetchApi.js";

export default function AuthModal({ onLogin }) {
  const [tab, setTab] = useState("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const result =
        tab === "login"
          ? await login(email, password)
          : await register(name, email, password);

      const apiUser = result?.user || result?.data?.user || result;
      onLogin({
        name: apiUser?.name || name || "عميل نبض",
        email: apiUser?.email || email,
        isAdmin: Boolean(apiUser?.isAdmin ?? apiUser?.role === "admin") || email.includes("admin"),
        token: result?.token || result?.data?.token,
      });
    } catch (err) {
      // Keep the original demo behavior when no backend is configured/reachable.
      if (!import.meta.env.VITE_API_URL) {
        onLogin({
          name: name || "عميل نبض",
          email: email || "guest@nabd.sa",
          isAdmin: email.includes("admin"),
        });
      } else {
        setError(err.message || "تعذر الاتصال بالخادم");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="modal fade" id="authModal" tabIndex="-1">
      <section className="modal-dialog modal-dialog-centered">
        <section className="modal-content rounded-xl border-soft">
          <header className="modal-header border-soft">
            <h5 className="modal-title">{tab === "login" ? "تسجيل الدخول" : "إنشاء حساب جديد"}</h5>
            <button type="button" className="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </header>
          <section className="modal-body">
            <ul className="nav nav-pills mb-4 gap-2">
              <li className="nav-item">
                <button type="button" className={`btn btn-sm rounded-3 ${tab === "login" ? "btn-nabd" : "btn-outline-nabd"}`} onClick={() => setTab("login")}>
                  دخول
                </button>
              </li>
              <li className="nav-item">
                <button type="button" className={`btn btn-sm rounded-3 ${tab === "register" ? "btn-nabd" : "btn-outline-nabd"}`} onClick={() => setTab("register")}>
                  حساب جديد
                </button>
              </li>
            </ul>
            <form onSubmit={submit} className="d-flex flex-column gap-3">
              {tab === "register" && (
                <p className="mb-0">
                  <label className="form-label small text-muted-2">الاسم الكامل</label>
                  <input
                    className="form-control rounded-3"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="مثال: سارة العتيبي"
                    required
                  />
                </p>
              )}
              <p className="mb-0">
                <label className="form-label small text-muted-2">البريد الإلكتروني</label>
                <input
                  type="email"
                  className="form-control rounded-3"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                />
              </p>
              <p className="mb-0">
                <label className="form-label small text-muted-2">كلمة المرور</label>
                <input
                type="password"
                className="form-control rounded-3"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
              </p>
              {error && <p className="text-danger small mb-0">{error}</p>}
              <button type="submit" className="btn btn-nabd rounded-3 py-2 mt-2" data-bs-dismiss={!error ? "modal" : undefined} disabled={loading}>
                {loading ? "جارٍ التنفيذ..." : tab === "login" ? "تسجيل الدخول" : "إنشاء الحساب"}
              </button>
              <p className="text-muted-2 small text-center mb-0">
                جرّب البريد "admin@nabd.sa" للدخول كمسؤول ومشاهدة لوحة إدارة الطلبات.
              </p>
            </form>
          </section>
        </section>
      </section>
    </section>
  );
}
